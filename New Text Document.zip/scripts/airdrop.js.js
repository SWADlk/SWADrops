const urlParams = new URLSearchParams(window.location.search);
const id = urlParams.get("id");

fetch('data/airdrops.json')
  .then(res => res.json())
  .then(data => {
    const drop = data.find(d => d.id === id);
    if (!drop) {
      document.getElementById('airdropDetail').innerHTML = `<p>Airdrop not found 😢</p>`;
      return;
    }

    document.getElementById('airdropDetail').innerHTML = `
      <h1>${drop.name}</h1>
      <img src="${drop.image}" alt="${drop.name}" style="max-width: 300px;" />
      <p>${drop.description}</p>
      <a href="${drop.refLink}" target="_blank" class="hero-btn">Join Airdrop</a>
    `;
  });
